import json
import os
import requests
import gspread
from oauth2client.service_account import ServiceAccountCredentials

# ----------------------
# Configuración de Google Sheets
# ----------------------
GOOGLE_CREDS_JSON = os.environ.get("GOOGLE_CREDS_JSON")  # JSON de credenciales como string
GOOGLE_SHEET_ID = os.environ.get("GOOGLE_SHEET_ID")      # ID del Sheet

def get_sheet():
    """Autenticación con Google Sheets"""
    try:
        creds_dict = json.loads(GOOGLE_CREDS_JSON)
        creds = ServiceAccountCredentials.from_json_keyfile_dict(
            creds_dict,
            ["https://spreadsheets.google.com/feeds",
             "https://www.googleapis.com/auth/drive"]
        )
        client = gspread.authorize(creds)
        sheet = client.open_by_key(GOOGLE_SHEET_ID).sheet1
        return sheet
    except Exception as e:
        print(f"❌ Error al autenticar Google Sheets: {e}")
        return None

# ----------------------
# Función para enviar mensaje a Telegram
# ----------------------
def enviar_respuesta_telegram(chat_id, texto):
    bot_token = os.environ.get("TELEGRAM_BOT_TOKEN")
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {"chat_id": chat_id, "text": texto, "parse_mode": "HTML"}
    try:
        r = requests.post(url, json=payload)
        r.raise_for_status()
        print(f"✅ Mensaje enviado a Telegram: {texto}")
    except Exception as e:
        print(f"❌ Error enviando mensaje a Telegram: {e}")

# ----------------------
# Handler principal Lambda
# ----------------------
def lambda_handler(event, context):
    try:
        print(f"🔹 Event recibido: {json.dumps(event)}")

        # Parsear correctamente el body
        body = event.get("body")
        if body:
            try:
                body = json.loads(body)
            except json.JSONDecodeError:
                print("❌ Error parseando body")
                return {"statusCode": 400, "body": json.dumps({"message": "Invalid JSON in body"})}
        else:
            body = event

        print(f"🔹 Body parseado: {json.dumps(body)}")

        # Verificar si existe 'message'
        message = body.get("message")
        if not message:
            print("❌ No se encontró 'message'")
            return {"statusCode": 400, "body": json.dumps({"message": "No message in event"})}

        chat_id = message["chat"]["id"]
        text = message["text"]

        print(f"🔹 Mensaje del chat {chat_id}: {text}")

        # Registrar en Google Sheets
        sheet = get_sheet()
        if sheet:
            sheet.append_row([chat_id, text])
            print(f"✅ Mensaje registrado en Google Sheets")
        else:
            print("❌ No se pudo registrar en Google Sheets")

        # Responder al usuario
        enviar_respuesta_telegram(chat_id, "Recibí tu mensaje!")

        return {"statusCode": 200, "body": json.dumps({"message": "Processed successfully"})}

    except Exception as e:
        print(f"❌ Error general: {e}")
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}
